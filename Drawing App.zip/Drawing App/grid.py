import pygame
pygame.init()
grids = [
    # Row 1
    pygame.Rect(0, 0, 25, 25), # 1
    pygame.Rect(25, 0, 25, 25), # 2
    pygame.Rect(50, 0, 25, 25), # 3
    pygame.Rect(75, 0, 25, 25), # 4
    pygame.Rect(100, 0, 25, 25), # 5
    pygame.Rect(125, 0, 25, 25), # 6
    pygame.Rect(150, 0, 25, 25), # 7
    pygame.Rect(175, 0, 25, 25), # 8
    pygame.Rect(200, 0, 25, 25), # 9
    pygame.Rect(225, 0, 25, 25), # 10
    pygame.Rect(250, 0, 25, 25), # 11
    pygame.Rect(275, 0, 25, 25), # 12
    pygame.Rect(300, 0, 25, 25), # 13
    pygame.Rect(325, 0, 25, 25), # 14
    pygame.Rect(350, 0, 25, 25), # 15
    pygame.Rect(375, 0, 25, 25), # 16
    pygame.Rect(400, 0, 25, 25), # 17
    pygame.Rect(425, 0, 25, 25), # 18
    pygame.Rect(450, 0, 25, 25), # 19
    pygame.Rect(475, 0, 25, 25), # 20

    # Row 2
    pygame.Rect(0, 25, 25, 25), # 1
    pygame.Rect(25, 25, 25, 25), # 2
    pygame.Rect(50, 25, 25, 25), # 3
    pygame.Rect(75, 25, 25, 25), # 4
    pygame.Rect(100, 25, 25, 25), # 5
    pygame.Rect(125, 25, 25, 25), # 6
    pygame.Rect(150, 25, 25, 25), # 7
    pygame.Rect(175, 25, 25, 25), # 8
    pygame.Rect(200, 25, 25, 25), # 9
    pygame.Rect(225, 25, 25, 25), # 10
    pygame.Rect(250, 25, 25, 25), # 11
    pygame.Rect(275, 25, 25, 25), # 12
    pygame.Rect(300, 25, 25, 25), # 13
    pygame.Rect(325, 25, 25, 25), # 14
    pygame.Rect(350, 25, 25, 25), # 15
    pygame.Rect(375, 25, 25, 25), # 16
    pygame.Rect(400, 25, 25, 25), # 17
    pygame.Rect(425, 25, 25, 25), # 18
    pygame.Rect(450, 25, 25, 25), # 19
    pygame.Rect(475, 25, 25, 25), # 20

    # Row 3
    pygame.Rect(0, 50, 25, 25), # 1
    pygame.Rect(25, 50, 25, 25), # 2
    pygame.Rect(50, 50, 25, 25), # 3
    pygame.Rect(75, 50, 25, 25), # 4
    pygame.Rect(100, 50, 25, 25), # 5
    pygame.Rect(125, 50, 25, 25), # 6
    pygame.Rect(150, 50, 25, 25), # 7
    pygame.Rect(175, 50, 25, 25), # 8
    pygame.Rect(200, 50, 25, 25), # 9
    pygame.Rect(225, 50, 25, 25), # 10
    pygame.Rect(250, 50, 25, 25), # 11
    pygame.Rect(275, 50, 25, 25), # 12
    pygame.Rect(300, 50, 25, 25), # 13
    pygame.Rect(325, 50, 25, 25), # 14
    pygame.Rect(350, 50, 25, 25), # 15
    pygame.Rect(375, 50, 25, 25), # 16
    pygame.Rect(400, 50, 25, 25), # 17
    pygame.Rect(425, 50, 25, 25), # 18
    pygame.Rect(450, 50, 25, 25), # 19
    pygame.Rect(475, 50, 25, 25), # 20

    # Row 4
    pygame.Rect(0, 75, 25, 25), # 1
    pygame.Rect(25, 75, 25, 25), # 2
    pygame.Rect(50, 75, 25, 25), # 3
    pygame.Rect(75, 75, 25, 25), # 4
    pygame.Rect(100, 75, 25, 25), # 5
    pygame.Rect(125, 75, 25, 25), # 6
    pygame.Rect(150, 75, 25, 25), # 7
    pygame.Rect(175, 75, 25, 25), # 8
    pygame.Rect(200, 75, 25, 25), # 9
    pygame.Rect(225, 75, 25, 25), # 10
    pygame.Rect(250, 75, 25, 25), # 11
    pygame.Rect(275, 75, 25, 25), # 12
    pygame.Rect(300, 75, 25, 25), # 13
    pygame.Rect(325, 75, 25, 25), # 14
    pygame.Rect(350, 75, 25, 25), # 15
    pygame.Rect(375, 75, 25, 25), # 16
    pygame.Rect(400, 75, 25, 25), # 17
    pygame.Rect(425, 75, 25, 25), # 18
    pygame.Rect(450, 75, 25, 25), # 19
    pygame.Rect(475, 75, 25, 25), # 20

    # Row 5
    pygame.Rect(0, 100, 25, 25), # 1
    pygame.Rect(25, 100, 25, 25), # 2
    pygame.Rect(50, 100, 25, 25), # 3
    pygame.Rect(75, 100, 25, 25), # 4
    pygame.Rect(100, 100, 25, 25), # 5
    pygame.Rect(125, 100, 25, 25), # 6
    pygame.Rect(150, 100, 25, 25), # 7
    pygame.Rect(175, 100, 25, 25), # 8
    pygame.Rect(200, 100, 25, 25), # 9
    pygame.Rect(225, 100, 25, 25), # 10
    pygame.Rect(250, 100, 25, 25), # 11
    pygame.Rect(275, 100, 25, 25), # 12
    pygame.Rect(300, 100, 25, 25), # 13
    pygame.Rect(325, 100, 25, 25), # 14
    pygame.Rect(350, 100, 25, 25), # 15
    pygame.Rect(375, 100, 25, 25), # 16
    pygame.Rect(400, 100, 25, 25), # 17
    pygame.Rect(425, 100, 25, 25), # 18
    pygame.Rect(450, 100, 25, 25), # 19
    pygame.Rect(475, 100, 25, 25), # 20

    # Row 6
    pygame.Rect(0, 125, 25, 25), # 1
    pygame.Rect(25, 125, 25, 25), # 2
    pygame.Rect(50, 125, 25, 25), # 3
    pygame.Rect(75, 125, 25, 25), # 4
    pygame.Rect(100, 125, 25, 25), # 5
    pygame.Rect(125, 125, 25, 25), # 6
    pygame.Rect(150, 125, 25, 25), # 7
    pygame.Rect(175, 125, 25, 25), # 8
    pygame.Rect(200, 125, 25, 25), # 9
    pygame.Rect(225, 125, 25, 25), # 10
    pygame.Rect(250, 125, 25, 25), # 11
    pygame.Rect(275, 125, 25, 25), # 12
    pygame.Rect(300, 125, 25, 25), # 13
    pygame.Rect(325, 125, 25, 25), # 14
    pygame.Rect(350, 125, 25, 25), # 15
    pygame.Rect(375, 125, 25, 25), # 16
    pygame.Rect(400, 125, 25, 25), # 17
    pygame.Rect(425, 125, 25, 25), # 18
    pygame.Rect(450, 125, 25, 25), # 19
    pygame.Rect(475, 125, 25, 25), # 20

    # Row 7
    pygame.Rect(0, 150, 25, 25), # 1
    pygame.Rect(25, 150, 25, 25), # 2
    pygame.Rect(50, 150, 25, 25), # 3
    pygame.Rect(75, 150, 25, 25), # 4
    pygame.Rect(100, 150, 25, 25), # 5
    pygame.Rect(125, 150, 25, 25), # 6
    pygame.Rect(150, 150, 25, 25), # 7
    pygame.Rect(175, 150, 25, 25), # 8
    pygame.Rect(200, 150, 25, 25), # 9
    pygame.Rect(225, 150, 25, 25), # 10
    pygame.Rect(250, 150, 25, 25), # 11
    pygame.Rect(275, 150, 25, 25), # 12
    pygame.Rect(300, 150, 25, 25), # 13
    pygame.Rect(325, 150, 25, 25), # 14
    pygame.Rect(350, 150, 25, 25), # 15
    pygame.Rect(375, 150, 25, 25), # 16
    pygame.Rect(400, 150, 25, 25), # 17
    pygame.Rect(425, 150, 25, 25), # 18
    pygame.Rect(450, 150, 25, 25), # 19
    pygame.Rect(475, 150, 25, 25), # 20

    # Row 8
    pygame.Rect(0, 175, 25, 25), # 1
    pygame.Rect(25, 175, 25, 25), # 2
    pygame.Rect(50, 175, 25, 25), # 3
    pygame.Rect(75, 175, 25, 25), # 4
    pygame.Rect(100, 175, 25, 25), # 5
    pygame.Rect(125, 175, 25, 25), # 6
    pygame.Rect(150, 175, 25, 25), # 7
    pygame.Rect(175, 175, 25, 25), # 8
    pygame.Rect(200, 175, 25, 25), # 9
    pygame.Rect(225, 175, 25, 25), # 10
    pygame.Rect(250, 175, 25, 25), # 11
    pygame.Rect(275, 175, 25, 25), # 12
    pygame.Rect(300, 175, 25, 25), # 13
    pygame.Rect(325, 175, 25, 25), # 14
    pygame.Rect(350, 175, 25, 25), # 15
    pygame.Rect(375, 175, 25, 25), # 16
    pygame.Rect(400, 175, 25, 25), # 17
    pygame.Rect(425, 175, 25, 25), # 18
    pygame.Rect(450, 175, 25, 25), # 19
    pygame.Rect(475, 175, 25, 25), # 20

    # Row 9
    pygame.Rect(0, 200, 25, 25), # 1
    pygame.Rect(25, 200, 25, 25), # 2
    pygame.Rect(50, 200, 25, 25), # 3
    pygame.Rect(75, 200, 25, 25), # 4
    pygame.Rect(100, 200, 25, 25), # 5
    pygame.Rect(125, 200, 25, 25), # 6
    pygame.Rect(150, 200, 25, 25), # 7
    pygame.Rect(175, 200, 25, 25), # 8
    pygame.Rect(200, 200, 25, 25), # 9
    pygame.Rect(225, 200, 25, 25), # 10
    pygame.Rect(250, 200, 25, 25), # 11
    pygame.Rect(275, 200, 25, 25), # 12
    pygame.Rect(300, 200, 25, 25), # 13
    pygame.Rect(325, 200, 25, 25), # 14
    pygame.Rect(350, 200, 25, 25), # 15
    pygame.Rect(375, 200, 25, 25), # 16
    pygame.Rect(400, 200, 25, 25), # 17
    pygame.Rect(425, 200, 25, 25), # 18
    pygame.Rect(450, 200, 25, 25), # 19
    pygame.Rect(475, 200, 25, 25), # 20

    # Row 10
    pygame.Rect(0, 225, 25, 25), # 1
    pygame.Rect(25, 225, 25, 25), # 2
    pygame.Rect(50, 225, 25, 25), # 3
    pygame.Rect(75, 225, 25, 25), # 4
    pygame.Rect(100, 225, 25, 25), # 5
    pygame.Rect(125, 225, 25, 25), # 6
    pygame.Rect(150, 225, 25, 25), # 7
    pygame.Rect(175, 225, 25, 25), # 8
    pygame.Rect(200, 225, 25, 25), # 9
    pygame.Rect(225, 225, 25, 25), # 10
    pygame.Rect(250, 225, 25, 25), # 11
    pygame.Rect(275, 225, 25, 25), # 12
    pygame.Rect(300, 225, 25, 25), # 13
    pygame.Rect(325, 225, 25, 25), # 14
    pygame.Rect(350, 225, 25, 25), # 15
    pygame.Rect(375, 225, 25, 25), # 16
    pygame.Rect(400, 225, 25, 25), # 17
    pygame.Rect(425, 225, 25, 25), # 18
    pygame.Rect(450, 225, 25, 25), # 19
    pygame.Rect(475, 225, 25, 25), # 20

    # Row 11
    pygame.Rect(0, 250, 25, 25), # 1
    pygame.Rect(25, 250, 25, 25), # 2
    pygame.Rect(50, 250, 25, 25), # 3
    pygame.Rect(75, 250, 25, 25), # 4
    pygame.Rect(100, 250, 25, 25), # 5
    pygame.Rect(125, 250, 25, 25), # 6
    pygame.Rect(150, 250, 25, 25), # 7
    pygame.Rect(175, 250, 25, 25), # 8
    pygame.Rect(200, 250, 25, 25), # 9
    pygame.Rect(225, 250, 25, 25), # 10
    pygame.Rect(250, 250, 25, 25), # 11
    pygame.Rect(275, 250, 25, 25), # 12
    pygame.Rect(300, 250, 25, 25), # 13
    pygame.Rect(325, 250, 25, 25), # 14
    pygame.Rect(350, 250, 25, 25), # 15
    pygame.Rect(375, 250, 25, 25), # 16
    pygame.Rect(400, 250, 25, 25), # 17
    pygame.Rect(425, 250, 25, 25), # 18
    pygame.Rect(450, 250, 25, 25), # 19
    pygame.Rect(475, 250, 25, 25), # 20

    # Row 12
    pygame.Rect(0, 275, 25, 25), # 1
    pygame.Rect(25, 275, 25, 25), # 2
    pygame.Rect(50, 275, 25, 25), # 3
    pygame.Rect(75, 275, 25, 25), # 4
    pygame.Rect(100, 275, 25, 25), # 5
    pygame.Rect(125, 275, 25, 25), # 6
    pygame.Rect(150, 275, 25, 25), # 7
    pygame.Rect(175, 275, 25, 25), # 8
    pygame.Rect(200, 275, 25, 25), # 9
    pygame.Rect(225, 275, 25, 25), # 10
    pygame.Rect(250, 275, 25, 25), # 11
    pygame.Rect(275, 275, 25, 25), # 12
    pygame.Rect(300, 275, 25, 25), # 13
    pygame.Rect(325, 275, 25, 25), # 14
    pygame.Rect(350, 275, 25, 25), # 15
    pygame.Rect(375, 275, 25, 25), # 16
    pygame.Rect(400, 275, 25, 25), # 17
    pygame.Rect(425, 275, 25, 25), # 18
    pygame.Rect(450, 275, 25, 25), # 19
    pygame.Rect(475, 275, 25, 25), # 20

    # Row 13
    pygame.Rect(0, 300, 25, 25), # 1
    pygame.Rect(25, 300, 25, 25), # 2
    pygame.Rect(50, 300, 25, 25), # 3
    pygame.Rect(75, 300, 25, 25), # 4
    pygame.Rect(100, 300, 25, 25), # 5
    pygame.Rect(125, 300, 25, 25), # 6
    pygame.Rect(150, 300, 25, 25), # 7
    pygame.Rect(175, 300, 25, 25), # 8
    pygame.Rect(200, 300, 25, 25), # 9
    pygame.Rect(225, 300, 25, 25), # 10
    pygame.Rect(250, 300, 25, 25), # 11
    pygame.Rect(275, 300, 25, 25), # 12
    pygame.Rect(300, 300, 25, 25), # 13
    pygame.Rect(325, 300, 25, 25), # 14
    pygame.Rect(350, 300, 25, 25), # 15
    pygame.Rect(375, 300, 25, 25), # 16
    pygame.Rect(400, 300, 25, 25), # 17
    pygame.Rect(425, 300, 25, 25), # 18
    pygame.Rect(450, 300, 25, 25), # 19
    pygame.Rect(475, 300, 25, 25), # 20

    # Row 14
    pygame.Rect(0, 325, 25, 25), # 1
    pygame.Rect(25, 325, 25, 25), # 2
    pygame.Rect(50, 325, 25, 25), # 3
    pygame.Rect(75, 325, 25, 25), # 4
    pygame.Rect(100, 325, 25, 25), # 5
    pygame.Rect(125, 325, 25, 25), # 6
    pygame.Rect(150, 325, 25, 25), # 7
    pygame.Rect(175, 325, 25, 25), # 8
    pygame.Rect(200, 325, 25, 25), # 9
    pygame.Rect(225, 325, 25, 25), # 10
    pygame.Rect(250, 325, 25, 25), # 11
    pygame.Rect(275, 325, 25, 25), # 12
    pygame.Rect(300, 325, 25, 25), # 13
    pygame.Rect(325, 325, 25, 25), # 14
    pygame.Rect(350, 325, 25, 25), # 15
    pygame.Rect(375, 325, 25, 25), # 16
    pygame.Rect(400, 325, 25, 25), # 17
    pygame.Rect(425, 325, 25, 25), # 18
    pygame.Rect(450, 325, 25, 25), # 19
    pygame.Rect(475, 325, 25, 25), # 20

    # Row 15
    pygame.Rect(0, 350, 25, 25), # 1
    pygame.Rect(25, 350, 25, 25), # 2
    pygame.Rect(50, 350, 25, 25), # 3
    pygame.Rect(75, 350, 25, 25), # 4
    pygame.Rect(100, 350, 25, 25), # 5
    pygame.Rect(125, 350, 25, 25), # 6
    pygame.Rect(150, 350, 25, 25), # 7
    pygame.Rect(175, 350, 25, 25), # 8
    pygame.Rect(200, 350, 25, 25), # 9
    pygame.Rect(225, 350, 25, 25), # 10
    pygame.Rect(250, 350, 25, 25), # 11
    pygame.Rect(275, 350, 25, 25), # 12
    pygame.Rect(300, 350, 25, 25), # 13
    pygame.Rect(325, 350, 25, 25), # 14
    pygame.Rect(350, 350, 25, 25), # 15
    pygame.Rect(375, 350, 25, 25), # 16
    pygame.Rect(400, 350, 25, 25), # 17
    pygame.Rect(425, 350, 25, 25), # 18
    pygame.Rect(450, 350, 25, 25), # 19
    pygame.Rect(475, 350, 25, 25), # 20

    # Row 16
    pygame.Rect(0, 375, 25, 25), # 1
    pygame.Rect(25, 375, 25, 25), # 2
    pygame.Rect(50, 375, 25, 25), # 3
    pygame.Rect(75, 375, 25, 25), # 4
    pygame.Rect(100, 375, 25, 25), # 5
    pygame.Rect(125, 375, 25, 25), # 6
    pygame.Rect(150, 375, 25, 25), # 7
    pygame.Rect(175, 375, 25, 25), # 8
    pygame.Rect(200, 375, 25, 25), # 9
    pygame.Rect(225, 375, 25, 25), # 10
    pygame.Rect(250, 375, 25, 25), # 11
    pygame.Rect(275, 375, 25, 25), # 12
    pygame.Rect(300, 375, 25, 25), # 13
    pygame.Rect(325, 375, 25, 25), # 14
    pygame.Rect(350, 375, 25, 25), # 15
    pygame.Rect(375, 375, 25, 25), # 16
    pygame.Rect(400, 375, 25, 25), # 17
    pygame.Rect(425, 375, 25, 25), # 18
    pygame.Rect(450, 375, 25, 25), # 19
    pygame.Rect(475, 375, 25, 25), # 20

    # Row 17
    pygame.Rect(0, 400, 25, 25), # 1
    pygame.Rect(25, 400, 25, 25), # 2
    pygame.Rect(50, 400, 25, 25), # 3
    pygame.Rect(75, 400, 25, 25), # 4
    pygame.Rect(100, 400, 25, 25), # 5
    pygame.Rect(125, 400, 25, 25), # 6
    pygame.Rect(150, 400, 25, 25), # 7
    pygame.Rect(175, 400, 25, 25), # 8
    pygame.Rect(200, 400, 25, 25), # 9
    pygame.Rect(225, 400, 25, 25), # 10
    pygame.Rect(250, 400, 25, 25), # 11
    pygame.Rect(275, 400, 25, 25), # 12
    pygame.Rect(300, 400, 25, 25), # 13
    pygame.Rect(325, 400, 25, 25), # 14
    pygame.Rect(350, 400, 25, 25), # 15
    pygame.Rect(375, 400, 25, 25), # 16
    pygame.Rect(400, 400, 25, 25), # 17
    pygame.Rect(425, 400, 25, 25), # 18
    pygame.Rect(450, 400, 25, 25), # 19
    pygame.Rect(475, 400, 25, 25), # 20

    # Row 18
    pygame.Rect(0, 425, 25, 25), # 1
    pygame.Rect(25, 425, 25, 25), # 2
    pygame.Rect(50, 425, 25, 25), # 3
    pygame.Rect(75, 425, 25, 25), # 4
    pygame.Rect(100, 425, 25, 25), # 5
    pygame.Rect(125, 425, 25, 25), # 6
    pygame.Rect(150, 425, 25, 25), # 7
    pygame.Rect(175, 425, 25, 25), # 8
    pygame.Rect(200, 425, 25, 25), # 9
    pygame.Rect(225, 425, 25, 25), # 10
    pygame.Rect(250, 425, 25, 25), # 11
    pygame.Rect(275, 425, 25, 25), # 12
    pygame.Rect(300, 425, 25, 25), # 13
    pygame.Rect(325, 425, 25, 25), # 14
    pygame.Rect(350, 425, 25, 25), # 15
    pygame.Rect(375, 425, 25, 25), # 16
    pygame.Rect(400, 425, 25, 25), # 17
    pygame.Rect(425, 425, 25, 25), # 18
    pygame.Rect(450, 425, 25, 25), # 19
    pygame.Rect(475, 425, 25, 25), # 20

    # Row 19
    pygame.Rect(0, 450, 25, 25), # 1
    pygame.Rect(25, 450, 25, 25), # 2
    pygame.Rect(50, 450, 25, 25), # 3
    pygame.Rect(75, 450, 25, 25), # 4
    pygame.Rect(100, 450, 25, 25), # 5
    pygame.Rect(125, 450, 25, 25), # 6
    pygame.Rect(150, 450, 25, 25), # 7
    pygame.Rect(175, 450, 25, 25), # 8
    pygame.Rect(200, 450, 25, 25), # 9
    pygame.Rect(225, 450, 25, 25), # 10
    pygame.Rect(250, 450, 25, 25), # 11
    pygame.Rect(275, 450, 25, 25), # 12
    pygame.Rect(300, 450, 25, 25), # 13
    pygame.Rect(325, 450, 25, 25), # 14
    pygame.Rect(350, 450, 25, 25), # 15
    pygame.Rect(375, 450, 25, 25), # 16
    pygame.Rect(400, 450, 25, 25), # 17
    pygame.Rect(425, 450, 25, 25), # 18
    pygame.Rect(450, 450, 25, 25), # 19
    pygame.Rect(475, 450, 25, 25), # 20

    # Row 20
    pygame.Rect(0, 475, 25, 25), # 1
    pygame.Rect(25, 475, 25, 25), # 2
    pygame.Rect(50, 475, 25, 25), # 3
    pygame.Rect(75, 475, 25, 25), # 4
    pygame.Rect(100, 475, 25, 25), # 5
    pygame.Rect(125, 475, 25, 25), # 6
    pygame.Rect(150, 475, 25, 25), # 7
    pygame.Rect(175, 475, 25, 25), # 8
    pygame.Rect(200, 475, 25, 25), # 9
    pygame.Rect(225, 475, 25, 25), # 10
    pygame.Rect(250, 475, 25, 25), # 11
    pygame.Rect(275, 475, 25, 25), # 12
    pygame.Rect(300, 475, 25, 25), # 13
    pygame.Rect(325, 475, 25, 25), # 14
    pygame.Rect(350, 475, 25, 25), # 15
    pygame.Rect(375, 475, 25, 25), # 16
    pygame.Rect(400, 475, 25, 25), # 17
    pygame.Rect(425, 475, 25, 25), # 18
    pygame.Rect(450, 475, 25, 25), # 19
    pygame.Rect(475, 475, 25, 25), # 20
]
COLORS = [
    # Colors
    pygame.Rect(0, 500, 50, 50), # BLACK
    pygame.Rect(50, 500, 50, 50), # WHITE
    pygame.Rect(100, 500, 50, 50), # YELLOW
    pygame.Rect(150, 500, 50, 50), # ORANGE
    pygame.Rect(200, 500, 50, 50), # RED
    pygame.Rect(250, 500, 50, 50), # PINK
    pygame.Rect(300, 500, 50, 50), # PURPLE
    pygame.Rect(350, 500, 50, 50), # BLUE
    pygame.Rect(400, 500, 50, 50), # GREEN
    pygame.Rect(450, 500, 50, 50), # BROWN
]