# Modules 
import pygame
from pygame.locals import *
from grid import grids, COLORS
pygame.init()

# Screen
screen_width, screen_height = 500, 550
screen = pygame.display.set_mode((screen_width, screen_height))

# Title and Icon
pygame.display.set_caption("Drawing App")
icon = pygame.image.load("Assets/icon.png").convert(screen)
pygame.display.set_icon(icon)



# Game Vars
clock = pygame.time.Clock()
FPS = 60
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
YELLOW = (255, 241, 0)
ORANGE = (255, 140, 0)
RED = (232, 17, 35)
PINK = (236, 0, 140)
PURPLE = (104, 33, 122)
BLUE = (0, 24, 143)
GREEN = (31, 135, 3)
BROWN = (56, 32, 15)

# Blit onto screen
def draw(mouse_rect, mouse_press, COLOR, black, white, yellow, orange, red, pink, purple, blue, green, brown):
    screen.fill(WHITE)
    for grid in grids:
        pygame.draw.rect(screen, BLACK, grid, 1) # this draws the grids
        if mouse_rect.colliderect(grid):
            if mouse_press[0]:
                if COLOR == BLACK: # These append diffrent colors with a left-click to their own list where you can show thme separately
                    black.append(grid)
                if COLOR == WHITE:
                    white.append(grid)
                if COLOR == YELLOW:
                    yellow.append(grid)
                if COLOR == ORANGE:
                    orange.append(grid)
                if COLOR == RED:
                    red.append(grid)
                if COLOR == PINK:
                    pink.append(grid)
                if COLOR == PURPLE:
                    purple.append(grid)
                if COLOR == BLUE:
                    blue.append(grid)
                if COLOR == GREEN:
                    green.append(grid)
                if COLOR == BROWN:
                    brown.append(grid)
            if mouse_press[2]:
                if grid in black: # these remove diffrent colors from diffrent lists on a right-click
                    black.remove(grid)
                if grid in white:
                    white.remove(grid)
                if grid in yellow:
                    yellow.remove(grid)
                if grid in orange:
                    orange.remove(grid)
                if grid in red:
                    red.remove(grid)
                if grid in pink:
                    pink.remove(grid)
                if grid in purple:
                    purple.remove(grid)
                if grid in blue:
                    blue.remove(grid)
                if grid in green:
                    green.remove(grid)
                if grid in brown:
                    brown.remove(grid)
    for grid in black: # These run through all the lists and check if a color is in a grid 
        pygame.draw.rect(screen, BLACK, grid)
    for grid in white:
        pygame.draw.rect(screen, WHITE, grid)
    for grid in yellow:
        pygame.draw.rect(screen, YELLOW, grid)
    for grid in orange:
        pygame.draw.rect(screen, ORANGE, grid)
    for grid in red:
        pygame.draw.rect(screen, RED, grid)
    for grid in pink:
        pygame.draw.rect(screen, PINK, grid)
    for grid in purple:
        pygame.draw.rect(screen, PURPLE, grid)
    for grid in blue:
        pygame.draw.rect(screen, BLUE, grid)
    for grid in green:
        pygame.draw.rect(screen, GREEN, grid)
    for grid in brown:
        pygame.draw.rect(screen, BROWN, grid)

    pygame.draw.rect(screen, BLACK, COLORS[0]) # These just show the colors you can pick from
    pygame.draw.rect(screen, WHITE, COLORS[1])
    pygame.draw.rect(screen, YELLOW, COLORS[2])
    pygame.draw.rect(screen, ORANGE, COLORS[3])
    pygame.draw.rect(screen, RED, COLORS[4])
    pygame.draw.rect(screen, PINK, COLORS[5])
    pygame.draw.rect(screen, PURPLE, COLORS[6])
    pygame.draw.rect(screen, BLUE, COLORS[7])
    pygame.draw.rect(screen, GREEN, COLORS[8])
    pygame.draw.rect(screen, BROWN, COLORS[9])
    pygame.display.update()

# Gameloop
def main():
    running = True
    COLOR = BLACK
    black = [] # These lists are used to display a multitude of colors
    white = []
    yellow = []
    orange = []
    red = []
    pink = []
    purple = []
    blue = []
    green = []
    brown = []
    while running:
        clock.tick(FPS)
        mouse_rect = pygame.Rect(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1], 1, 1) # This is used to get the mouse position
        mouse_press = pygame.mouse.get_pressed(3)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if mouse_press[0]:
            if mouse_rect.colliderect(COLORS[0]): # These if statements are for changing the color
                COLOR = BLACK
            if mouse_rect.colliderect(COLORS[1]):
                COLOR = WHITE
            if mouse_rect.colliderect(COLORS[2]):
                COLOR = YELLOW
            if mouse_rect.colliderect(COLORS[3]):
                COLOR = ORANGE
            if mouse_rect.colliderect(COLORS[4]):
                COLOR = RED
            if mouse_rect.colliderect(COLORS[5]):
                COLOR = PINK
            if mouse_rect.colliderect(COLORS[6]):
                COLOR = PURPLE
            if mouse_rect.colliderect(COLORS[7]):
                COLOR = BLUE
            if mouse_rect.colliderect(COLORS[8]):
                COLOR = GREEN
            if mouse_rect.colliderect(COLORS[9]):
                COLOR = BROWN

        draw(mouse_rect, mouse_press, COLOR, black, white, yellow, orange, red, pink, purple, blue, green, brown)

if __name__ == "__main__":
    main()
        